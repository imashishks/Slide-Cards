define({ 

   onPreShow: function(){
    var i = 80;
    var opacity = 1;
    var centerValue = 50;

     for(var a =0 ; a < 5 ; a++){
     	var flexContainer1 = new kony.ui.FlexContainer({
            "id": "fl"+(a + 1),
            "top": "0dp",
            "left": "0dp",
            "width": i +"%",
            "height": "250dp",
            "zIndex": i,
            "skin": "CopyslFbox0e683d911013245",
            "opacity": opacity,
            "backgroundColor": "ffffff",
            "centerX": "50%",
            "centerY" : centerValue+ "%",
            "isVisible": true,
            "clipBounds": true,
            "layoutType": kony.flex.FREE_FORM
          }, {
              "padding": [0, 0, 0, 0]
          }, {});

         flexContainer1.setDefaultUnit(kony.flex.DP);
         flexContainer1.add();
         this.view.flxParent.add(flexContainer1);
         
         opacity = opacity - 0.1;
         i = i-5;
         centerValue = centerValue - 2;
     }
     this.callbackSingleTapGesture();
   },
  
   animate:function(widget,direction){
    var wdgt= this.view.flxParent.widgets()[0];
    var self=this;
    switch(direction){
      case 1: 
        //left
        wdgt.animate(this.getAnimationObject("animateLeft",{width:wdgt.width,left:wdgt.left}),this.getAnimConfig({}),this.getCallback({
            animationStart:function(){
             	self.adjustWidgets();
            },
          animationEnd:function(){
             	
               var wdgt= self.view.flxParent.widgets()[0];
     			self.view.flxParent.remove(wdgt);
            }
       }));
      
       break;
      case 2:
       //right
        wdgt.animate(this.getAnimationObject("animateRight",{width:wdgt.width,left:wdgt.left}),this.getAnimConfig({}),this.getCallback({
             animationStart:function(){
             	self.adjustWidgets();
            },
          animationEnd:function(){
             	
               var wdgt= self.view.flxParent.widgets()[0];
     			self.view.flxParent.remove(wdgt);
            }
          	
       }));
       break;
    }
   },
   adjustWidgets: function(){
     var self=this;
     var wdgt= this.view.flxParent.widgets()[0];
//      this.view.flxParent.remove(wdgt);
     var centerValue = 50;
     var width = 80;
     var opacity = 1;
     this.view.flxParent.widgets().map(function(widget,index){
		if(index){
              var tempConfig={
         initial:{
           width:widget.width,
           centerY: widget.centerY,
           opacity: widget.opacity
         },
         final:{
           width:width +"%",
           centerY: centerValue +"%",
           opacity: opacity
//            width:(width - 5) +"%",
//            centerY: (centerValue - 2) +"%" ,
//            opacity: opacity - 0.1
         }
       };
       
       widget.animate(self.getAnimationObject("adjustWidget",tempConfig),self.getAnimConfig({}),self.getCallback({
            animationEnd:function(){
//              	self.adjustWidgets();
            }
       }));
         width = width - 5;
       centerValue = centerValue - 2 ;
       opacity = opacity - 0.1;
       
        }
     	
   
       
     });
     
  },
 
  getAnimationObject : function(animationType,params){
    var animeDef={};
    switch(animationType){
   
      case "animateLeft":
        var transformObject = kony.ui.makeAffineTransform();
        transformObject.rotate(0);
        var transformObject1 = kony.ui.makeAffineTransform();
        transformObject1.rotate(30);
        animeDef= {
          0:{
            "centerX": "50%",
            "opacity":1,
            "transform":transformObject
           },
          100:{
            "centerX" : "-100%",
            "opacity":0,
             "transform":transformObject1
           }
        };
        break;
        
      case "animateRight":
        var transformObject2 = kony.ui.makeAffineTransform();
        transformObject2.rotate(0);
        var transformObject3 = kony.ui.makeAffineTransform();
        transformObject3.rotate(-30);
         animeDef= {
          0:{
            "centerX": "50%",
            "opacity":1,
            "transform":transformObject2
           },
          100:{
            "centerX" : "200%",
            "opacity":0,
             "transform":transformObject3
           }
        };
       
        break;
        case "adjustWidget":
//         width = width - 5;
//        centerValue = centerValue - 2 ;
//        opacity = opacity - 0.1;
        
        //        widget.centerY = centerValue +"%";
//        widget.width = width +"%";
//        widget.opacity = opacity;
       
        
         animeDef= {
          0:{
            "centerY": params.initial.centerY,
            "width":params.initial.width,
            "opacity":params.initial.opacity
           },
          100:{
            "centerY": params.final.centerY,
            "width":params.final.width,
            "opacity":params.final.opacity
           }
        };
       
        break;
     }
    	
    return kony.ui.createAnimation(animeDef);
  },
  getAnimConfig:function(config){
  		var con = {
          "duration":0.5,
          "iterationCount":1,
          "delay":0,
          "direction":kony.anim.DIRECTION_ALTERNATE,
          "fillMode":kony.anim.FILL_MODE_BOTH
        };
    	config = Object.assign(con,config);
        return config;
  },
  getCallback:function(callbackObj){
    var tempObj={
      animationStart:function(){},
      animationEnd:function(){}
    };
   return Object.assign(tempObj,callbackObj);
  },  
  
  formGesture: function (widgetID,gestureInfo)
  {
	
	if(kony.os.toNumber(gestureInfo.gestureType) == 2)
	{
		h = gestureInfo.swipeDirection;
        if(this.view.flxParent.widgets().length === 0){
           return ;
        }
		this.animate(widgetID,h);
	}
 },
 callbackSingleTapGesture: function()
  {
      var x ={fingers:1};
      try{
          kony.application.setGestureRecognizerForAllForms(2, x, 
          this.formGesture);
      }
      catch(err){
          alert(typeof err);
          alert("error in function callbackSingleTapGesture: "+err.message);
      }
  }
  
 });