define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preshow defined for Form1 **/
    AS_Form_a042cf7e52844dbfaac818f5d76ee6ed: function AS_Form_a042cf7e52844dbfaac818f5d76ee6ed(eventobject) {
        var self = this;
        return self.onPreShow.call(this);
    }
});